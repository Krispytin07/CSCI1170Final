# CSCI 1170: Intro to Web Design and Development

## Student Info

Name: Kristin Gaudet

Student ID: B00972123

Email: kr536905@dal.ca 

## The FinalProject Deliverable

This is part of a deliverable for the final project during Winter 2024.

## References and Citations

1. Image content downloaded from: Adobe Stock, URL: [stock.adobe.com](https://stock.adobe.com/search?k=html+logo&asset_id=526845142), Date accessed: 9 Apr 2024
2. Image content downloaded from: Logos-World, URL: [Logos-World.net](https://logos-world.net/java-logo/), Date accessed: 9 Apr 2024
3. Image content downloaded from: BrandLogos, URL: [BrandLogos.com](https://www.google.com/url?sa=i&url=https%3A%2F%2Fbrandslogos.com%2Fa%2Farduino-logo-1%2F&psig=AOvVaw3wkx44tSza30IhPUFbOHeY&ust=1713318483392000&source=images&cd=vfe&opi=89978449&ved=0CBQQjhxqFwoTCNih5-7OxYUDFQAAAAAdAAAAABAE), Date accessed: 9 Apr 2024



